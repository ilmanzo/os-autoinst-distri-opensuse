
def test_addition():
    """
    A simple test to verify addition.
    This test will pass.
    """
    assert 8 - 3 == 5

def test_subtraction():
    """
    A simple test to verify subtraction.
    This test will also pass.
    """
    assert 7 + 3 == 10
