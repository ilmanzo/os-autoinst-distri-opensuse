# --- Configuration ---
DOMAIN = "EXAMPLE"
REALM = "EXAMPLE.INTERNAL"
ADMIN_PASS = "Passw0rd" # WARNING: Password in cleartext!
