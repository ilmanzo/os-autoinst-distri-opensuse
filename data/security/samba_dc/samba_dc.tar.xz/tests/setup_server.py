#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import sys
import re
import sh
import configparser # Import the configparser module

from common import *

# File paths
SMB_CONF = "/etc/samba/smb.conf"
SMB_CONF_ORIG = "/etc/samba/smb.conf.orig"
KRB5_CONF_SRC = "/var/lib/samba/private/krb5.conf"
KRB5_CONF_DEST = "/etc/krb5.conf"
RESOLV_CONF = "/etc/resolv.conf"

def check_root():
    """Checks if the script is being run as root."""
    if os.geteuid() != 0:
        print("Error: This script must be run as root. Use 'sudo'.")
        sys.exit(1)

def get_dns_from_resolv():
    """Extracts the first nameserver from /etc/resolv.conf."""
    print(f"Reading DNS from {RESOLV_CONF}")
    try:
        with open(RESOLV_CONF, 'r') as f:
            for line in f:
                match = re.search(r'^\s*nameserver\s+([\d.]+)', line)
                if match:
                    dns_ip = match.group(1)
                    print(f"Found DNS forwarder: {dns_ip}")
                    return dns_ip
        print(f"Warning: No 'nameserver' found in {RESOLV_CONF}.")
        return None
    except FileNotFoundError:
        print(f"Error: {RESOLV_CONF} not found.")
        return None

def main():
    """Main function that executes all steps."""
    check_root()
    print("Starting Samba Active Directory Domain Controller configuration...")

    try:
        # 1. Install packages
        print("Running: zypper in -y samba-ad-dc ...")
        sh.zypper("in", "-y", "samba-ad-dc", "samba-ad-dc-libs", "krb5-client")
        print("Success: Packages installed.")

        # 2. Rename the original smb.conf file
        if os.path.exists(SMB_CONF):
            print(f"Moving {SMB_CONF} to {SMB_CONF_ORIG}...")
            shutil.move(SMB_CONF, SMB_CONF_ORIG)
            print("File moved successfully.")

        # 3. Provision the domain
        print("Running: samba-tool domain provision ...")
        sh.samba_tool("domain", "provision",
            "--domain", DOMAIN,
            "--realm", REALM,
            "--adminpass", ADMIN_PASS,
            "--server-role=dc",
            "--use-rfc2307",
            "--dns-backend=SAMBA_INTERNAL"
        )
        print("Success: Domain provisioned.")

        # 4. Copy the krb5.conf file
        print(f"Copying {KRB5_CONF_SRC} to {KRB5_CONF_DEST}...")
        shutil.copy(KRB5_CONF_SRC, KRB5_CONF_DEST)
        print("File copied successfully.")

        # 5. Add configuration to krb5.conf
        with open(KRB5_CONF_DEST, 'r+') as f:
            krb_config = f.readlines()
        default_section=krb_config.index('[libdefaults]\n')
        krb_config.insert(default_section+1, 'default_ccache_name = FILE:/tmp/krb5cc_%{uid}\n')
        print(f"Updating {KRB5_CONF_DEST} with ccache name...")
        with open(KRB5_CONF_DEST, 'w') as f:
            f.write(''.join(krb_config))
        print("File updated.")

        # 6. Find the DNS and update smb.conf using configparser
        dns_forwarder = get_dns_from_resolv()
        if dns_forwarder:
            print(f"Updating {SMB_CONF} with DNS forwarder...")
            samba_config = configparser.ConfigParser()
            samba_config.read(SMB_CONF)
            # The [global] section must exist after provisioning, but we check to be safe
            if not samba_config.has_section('global'):
                 samba_config.add_section('global')
            samba_config.set('global', 'dns forwarder', dns_forwarder)
            with open(SMB_CONF, 'w') as f:
                samba_config.write(f)
            print("File updated.")

        # 7. Modify /etc/resolv.conf
        print(f"Writing new configuration to {RESOLV_CONF}...")
        with open(RESOLV_CONF, 'w') as f:
            f.write(f"search {REALM.lower()}\n")
            f.write("nameserver 127.0.0.1\n")
        print(f"{RESOLV_CONF} updated.")

        # 8. Enable and start the service
        print("Running: systemctl enable --now samba-ad-dc")
        sh.systemctl("enable", "--now", "samba-ad-dc")
        print("Success: Service enabled and started.")

    except sh.ErrorReturnCode as e:
        print("\nERROR: A command failed!")
        print(f"COMMAND: {e.full_cmd}")
        print(f"STDOUT:\n{e.stdout.decode()}")
        print(f"STDERR:\n{e.stderr.decode()}")
        sys.exit(1)
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        sys.exit(1)

    print("\nConfiguration completed successfully!")

if __name__ == "__main__":
    main()
