import sh
from io import StringIO
from common import *

def test_kinit():
    sh.kinit('Administrator', _in=sh.echo(ADMIN_PASS))

def test_klist():
    buf = StringIO()
    sh.klist(_out=buf)
    assert 'Administrator' in buf.getvalue()
